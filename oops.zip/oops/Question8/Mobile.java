package com.oops.Question8;

public class Mobile extends Electronic {
	public Mobile(String id, String semiconductorType, String dateOfManufacturing) {
		super(id, semiconductorType, dateOfManufacturing);
	}
}
