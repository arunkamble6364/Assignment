package com.oops.Question8;

public class LCD extends Electronic {
	public LCD(String id, String semiconductorType, String dateOfManufacturing) {
		super(id, semiconductorType, dateOfManufacturing);
	}

}
