package com.oops.Question5;

public class D extends C {
	@Override
	void div(int a, int b) {
		int div = a / b;
		System.out.println(div);
	}
}
