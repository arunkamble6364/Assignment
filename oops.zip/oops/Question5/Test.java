package com.oops.Question5;

public class Test {
	public static void main(String[] args) {

		A cd1 = new A();
		cd1.sum(4, 6);
		B cd2 = new B();
		cd2.sub(4, 6);
		C cd3 = new C();
		cd3.mul(4, 6);
		D cd4 = new D();
		cd4.div(4, 6);

	}
}
