package com.oops.Question5;

public abstract class CalcAbs {

	abstract void sum(int a, int b);

	void sub(int a, int b) {

	}

	void mul(int a, int b) {

	}

	void div(int a, int b) {

	}
}
