package com.oops.Question5;

public class A extends CalcAbs {
	@Override
	void sum(int a, int b) {
		int sum = a + b;
		System.out.println(sum);
	}
}
